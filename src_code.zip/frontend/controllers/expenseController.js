// controllers/expenseController.js
app.controller('ExpenseController', function($scope, ExpenseService) {
    $scope.expenses = [];
    $scope.newExpense = {};

    // Load all expenses
    $scope.loadExpenses = function() {
        ExpenseService.getAllExpenses().then(function(response) {
            $scope.expenses = response.data;
        });
    };

    // Add new expense
    $scope.addExpense = function() {
        ExpenseService.createExpense($scope.newExpense).then(function() {
            $scope.loadExpenses();
            $scope.newExpense = {};
        });
    };

    // Delete expense
    $scope.deleteExpense = function(id) {
        ExpenseService.deleteExpense(id).then(function() {
            $scope.loadExpenses();
        });
    };

    // Initialize expenses list
    $scope.loadExpenses();
});
