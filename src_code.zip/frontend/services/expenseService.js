// services/expenseService.js
app.service('ExpenseService', function($http) {
    const BASE_URL = 'http://localhost:8080/api/expenses';

    this.getAllExpenses = function() {
        return $http.get(BASE_URL);
    };

    this.getExpenseById = function(id) {
        return $http.get(`${BASE_URL}/${id}`);
    };

    this.createExpense = function(expense) {
        return $http.post(BASE_URL, expense);
    };

    this.updateExpense = function(id, expense) {
        return $http.put(`${BASE_URL}/${id}`, expense);
    };

    this.deleteExpense = function(id) {
        return $http.delete(`${BASE_URL}/${id}`);
    };
});
