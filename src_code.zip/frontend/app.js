// app.js
var app = angular.module('ExpenseApp', []);
